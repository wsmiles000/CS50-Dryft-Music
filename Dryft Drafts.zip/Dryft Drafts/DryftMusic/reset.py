from models import *

db.drop_all()
db.create_all()