from __future__ import print_function # In python 2.7
from flask import Flask
from flask.ext.sqlalchemy import SQLAlchemy
from sqlalchemy import distinct, func
from sqlalchemy.orm import scoped_session, sessionmaker
import os
from flask.ext.login import LoginManager
from flask import Blueprint, send_from_directory, request, render_template, redirect, flash, session, url_for, g
from flask.ext.login import login_user, logout_user, current_user, login_required
import json
import pdb
import os
from models import *

#API Import
import sys
import requests
import base64
import urllib
import soundcloud
import jinja2

global user

app = Flask(__name__)

db = SQLAlchemy(app)

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

lm = LoginManager()
lm.init_app(app)
lm.login_view = 'music'
app.secret_key = 'sdfdsaf.23409sdfnlksdfajk43[p[.sadfopk3'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////tmp/music.db'

#API Credentials

# Soundcloud Client Keys 
client = soundcloud.Client(client_id='b8c67b117b4c401d0bf33fa424582e2f',
                           client_secret='75e74dc71f780f742eda6c529235999f',
                           redirect_uri='http://127.0.0.1:8080/callback')

SOUNDCLOUD_CONNECT_URL = "https://soundcloud.com/connect"
SOUNDCLOUD_TOKEN_URL = "https://api.soundcloud.com/oauth2/token"
SOUNDCLOUD_API_BASE_URL = "https://api.soundcloud.com"
SOUNDCLOUD_API_URL = "{}".format(SOUNDCLOUD_API_BASE_URL)

#  Spotify Client Keys
CLIENT_ID = "0a71e6cca357487daa7b0ffaa20e68ad"
CLIENT_SECRET = "c56ffef6094f4246b995fbaf0c587953"

# Spotify URLS
SPOTIFY_AUTH_URL = "https://accounts.spotify.com/authorize"
SPOTIFY_TOKEN_URL = "https://accounts.spotify.com/api/token"
SPOTIFY_API_BASE_URL = "https://api.spotify.com"
API_VERSION = "v1"
SPOTIFY_API_URL = "{}/{}".format(SPOTIFY_API_BASE_URL, API_VERSION)

# Server-side Parameters (Spotify)
CLIENT_SIDE_URL = "http://127.0.0.1"
PORT = 5000
REDIRECT_URI = "{}:{}/callback/q".format(CLIENT_SIDE_URL, PORT)
SCOPE = "playlist-modify-public playlist-modify-public"
STATE = ""
SHOW_DIALOG_bool = True
SHOW_DIALOG_str = str(SHOW_DIALOG_bool).lower()


auth_query_parameters = {
    "response_type": "code",
    "redirect_uri": REDIRECT_URI,
    "scope": SCOPE,
    # "state": STATE,
    # "show_dialog": SHOW_DIALOG_str,
    "client_id": CLIENT_ID
}

@app.route("/")
def index():
    return render_template('index2.html')

@lm.user_loader
def load_user(id):
    return User.query.get(int(id))

@app.route("/music")
@login_required
def music(): 
    return render_template('music.html')

@app.route('/showSignUp')
def showSignUp():
    return render_template('signup2.html')

@app.route('/signUp', methods=['Post'])
def signUp():
#    if g.user is not None and g.user.is_authenticated():
#        return redirect(url_for('music'))
    username = request.form['inputName'].capitalize()
    email = request.form['inputEmail'].lower()
    password = request.form['inputPassword']
    if User.query.filter(User.email == email).first() is not None:
        flash('Account already exists for this email address! Please try signing in.')
        return redirect(url_for('user.login', defaultEmail=email))
    if User.query.filter(User.email == email).first() is not None:
        flash('Account already exists for this email address! Please try signing in.')
        return redirect(url_for('user.login', defaultEmail=email))
    user = User(username=username, email=email)
    user.hash_password(password)
    db.session.add(user)
    db.session.commit()
    login_user(user)
    return redirect(url_for('music'))
       
@app.route('/showSignIn')
def showSignIn():
    return render_template('signin2.html')

@app.route('/signIn', methods =['Post'])
def signIn():
    #if g.user is not None and g.user.is_authenticated():
     #   return redirect(url_for('music'))
    if request.method == 'GET':
        email = request.args.get('defaultEmail')
        return render_template('login.html', defaultEmail=email)
    email = request.form['inputEmail'].lower()
    password = request.form['inputPassword']
    user = User.query.filter(User.email == email).first()
    if user is None:
        flash('Email is invalid!')
        return redirect(url_for('signIn'))
    if user.verify_password(password) is False:
        flash('Password is invalid!')
        return redirect(url_for('signIn'))
    #if (user.account_approved is False) :
     #   return redirect(url_for('user.unvalidated'))
    login_user(user)
    return redirect(url_for("music"))

@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have logged out")
    return redirect(url_for("index"))

@app.route("/linkaccounts")
@login_required
def link():
    return render_template('link.html')

#API Routing

@app.route("/spotify")
def spotify():
    # Auth Step 1: Authorization
    url_args = "&".join(["{}={}".format(key,urllib.quote(val)) for key,val in auth_query_parameters.iteritems()])
    auth_url = "{}/?{}".format(SPOTIFY_AUTH_URL, url_args)
    return redirect(auth_url)

@app.route("/soundcloud")
def soundcloud():
    return redirect(client.authorize_url())

#Spotify Callback Route
@app.route("/callback/q")
def callback():
    # Auth Step 4: Requests refresh and access tokens
    auth_token = request.args['code']
    code_payload = {
        "grant_type": "authorization_code",
        "code": str(auth_token),
        "redirect_uri": REDIRECT_URI
    }
    base64encoded = base64.b64encode("{}:{}".format(CLIENT_ID, CLIENT_SECRET))
    headers = {"Authorization": "Basic {}".format(base64encoded)}
    post_request = requests.post(SPOTIFY_TOKEN_URL, data=code_payload, headers=headers)

    # Auth Step 5: Tokens are Returned to Application
    response_data = json.loads(post_request.text)
    access_token = response_data["access_token"]
    refresh_token = response_data["refresh_token"]
    token_type = response_data["token_type"]
    expires_in = response_data["expires_in"]

    # Auth Step 6: Use the access token to access Spotify API
    authorization_header = {"Authorization":"Bearer {}".format(access_token)}

    # Get profile data
    user_profile_api_endpoint = "{}/me".format(SPOTIFY_API_URL)
    profile_response = requests.get(user_profile_api_endpoint, headers=authorization_header)
    profile_data = json.loads(profile_response.text)

    # Get user playlist data
    playlist_api_endpoint = "{}/playlists".format(profile_data["href"])
    playlist_response = requests.get(playlist_api_endpoint, headers=authorization_header)
    playlist_data = json.loads(playlist_response.text)
    
    # Combine profile and playlist data to display
    display_arr = playlist_data["items"]

    uri_all = []
    for element in display_arr:
        uri_id = element['uri']
        uri_all.append(uri_id)

    id_all = []
    for owners in display_arr:
        owner_id = owners['owner']['id']
        id_all.append(owner_id)

    playlist_all = []
    for element in display_arr:
        playlist_id = element['id']
        playlist_all.append(playlist_id)


    return render_template("music.html", uri=uri_all, data=playlist_all, id=id_all, sorted_array=display_arr)

#Soundcloud Callback Route
@app.route("/callback")
def call():
    import soundcloud
    
    code=request.args.get('code')
    
    token = client.exchange_token(code)
    
    refresh = token.scope
    
    newclient = soundcloud.Client(access_token=token.access_token)
    
    username = newclient.get('/me').username
    
    playlist_count = newclient.get('/me').playlist_count
    
    url_list = []
    
    i = 0
    while i < playlist_count:
        url_list.append(newclient.get('/me/playlists')[i].uri)
        i+=1
        
    url_list = url_list
    
    stream_url1 = newclient.get('/me/playlists')[0].uri
    
    
    favorites = newclient.get('/me').uri + "/favorites" 
    
    return render_template("soundcloud.html", stream_url1=stream_url1, username=username, favorites=favorites, playlist_count=playlist_count, url_list=url_list)


if __name__ == "__main__":
    app.run(debug=True)